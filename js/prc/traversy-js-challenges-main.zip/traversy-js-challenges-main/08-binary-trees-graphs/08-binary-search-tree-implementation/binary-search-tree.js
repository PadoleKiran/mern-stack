class Node {}

class BinarySearchTree {}

module.exports = { Node, BinarySearchTree };
