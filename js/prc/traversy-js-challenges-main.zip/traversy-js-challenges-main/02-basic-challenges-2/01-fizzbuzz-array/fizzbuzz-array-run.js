const fizzBuzzArray = require('./fizzbuzz-array');

const result = fizzBuzzArray(15);

console.log(result);
