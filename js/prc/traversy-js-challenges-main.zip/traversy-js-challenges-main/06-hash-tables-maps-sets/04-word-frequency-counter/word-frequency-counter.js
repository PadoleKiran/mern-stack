function wordFrequencyCounter() {}

module.exports = wordFrequencyCounter;
