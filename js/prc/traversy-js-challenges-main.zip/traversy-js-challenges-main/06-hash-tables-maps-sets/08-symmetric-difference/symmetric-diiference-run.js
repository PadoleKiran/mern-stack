const symmetricDifference = require('./symmetric-difference');

const result = symmetricDifference([1, 2, 3], [2, 3, 4]);

console.log(result);
