class Stack {}

module.exports = Stack;
