function formatPhoneNumber() {}

module.exports = formatPhoneNumber;
