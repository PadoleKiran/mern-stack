const arrayIntersection = require('./array-intersection');

const result = arrayIntersection([1, 2, 3, 4, 5], [3, 4, 5, 6, 7]);

console.log(result);
