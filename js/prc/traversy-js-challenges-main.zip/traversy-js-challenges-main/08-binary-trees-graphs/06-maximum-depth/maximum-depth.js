class Node {}

function maxDepth() {}

module.exports = {
  maxDepth,
  Node,
};
