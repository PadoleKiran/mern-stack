class HashTable {}

module.exports = HashTable;
