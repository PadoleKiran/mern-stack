const numberRange = require('./number-range');

const result = numberRange(1, 5);

console.log(result);
