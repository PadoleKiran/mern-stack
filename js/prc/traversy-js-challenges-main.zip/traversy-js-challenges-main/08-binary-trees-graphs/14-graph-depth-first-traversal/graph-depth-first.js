const Stack = require('./stack');

function depthFirstTraversal() {}

module.exports = depthFirstTraversal;
