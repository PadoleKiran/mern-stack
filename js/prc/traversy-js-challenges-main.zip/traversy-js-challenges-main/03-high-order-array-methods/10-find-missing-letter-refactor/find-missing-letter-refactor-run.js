const findMissingLetter = require('./find-missing-letter-refactor');

const result = findMissingLetter(['a', 'b', 'c', 'e']);

console.log(result);
