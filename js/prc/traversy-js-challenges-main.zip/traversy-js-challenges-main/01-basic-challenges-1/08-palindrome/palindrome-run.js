const isPalindrome = require('./palindrome');

const result1 = isPalindrome('racecar');
const result2 = isPalindrome('racecars');

console.log(result1, result2);
