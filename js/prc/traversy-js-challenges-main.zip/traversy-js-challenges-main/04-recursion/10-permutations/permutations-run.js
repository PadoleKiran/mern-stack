const permutations = require('./permutations');

const result = permutations('abc');

console.log(result);
