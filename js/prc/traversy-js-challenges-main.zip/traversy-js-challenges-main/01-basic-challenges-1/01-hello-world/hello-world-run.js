const helloWorld = require('./hello-world');

const result = helloWorld();

console.log(result);
