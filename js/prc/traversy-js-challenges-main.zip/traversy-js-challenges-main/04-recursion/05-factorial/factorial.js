function factorial() {}

module.exports = factorial;
