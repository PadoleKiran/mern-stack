function validatePassword() {}

module.exports = validatePassword;
