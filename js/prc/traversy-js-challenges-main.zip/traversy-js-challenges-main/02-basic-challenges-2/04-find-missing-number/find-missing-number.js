function findMissingNumber() {}

module.exports = findMissingNumber;
