const findFirstNonRepeatingCharacter = require('./first-non-repeating');

const result1 = findFirstNonRepeatingCharacter('programming');
const result2 = findFirstNonRepeatingCharacter('abacddbec');

console.log(result1);
console.log(result2);
